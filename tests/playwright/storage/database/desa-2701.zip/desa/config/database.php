<?php
$db['default']['hostname'] = getenv('DB_HOST') ?: '127.0.0.1';
$db['default']['username'] = getenv('DB_USERNAME') ?: 'root';
$db['default']['password'] = getenv('DB_PASSWORD') ?: '';
$db['default']['port']     = (int) (getenv('DB_PORT') ?: 3306);
$db['default']['database'] = getenv('DB_DATABASE') ?: 'opensid_playwright_umum';
$db['default']['dbcollat'] = 'utf8mb4_general_ci';
$db['default']['stricton'] = true;
