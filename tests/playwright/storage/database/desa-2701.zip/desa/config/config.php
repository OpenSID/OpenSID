<?php
$config['base_url']   = getenv('PLAYWRIGHT_BASE_URL') ? getenv('PLAYWRIGHT_BASE_URL') . '/' : 'http://127.0.0.1:8010/';
$config['demo_mode']  = false;
$config['user_admin'] = 0;
