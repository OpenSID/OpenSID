<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        $configId = DB::table('config')->value('id') ?? 1;

        DB::table('setting_modul')->updateOrInsert(
            ['config_id' => $configId, 'slug' => 'contoh-modul'],
            [
                'modul'  => 'Contoh Modul',
                'url'    => 'contoh-modul',
                'aktif'  => 1,
                'ikon'   => 'fa-cube',
                'urut'   => 999,
                'level'  => 0,
                'hidden' => 0,
                'parent' => 0,
            ]
        );
    }

    public function down(): void
    {
        DB::table('setting_modul')->where('slug', 'contoh-modul')->delete();
    }
};
