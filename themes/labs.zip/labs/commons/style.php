<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<link rel="stylesheet" id="css-main"
    href="<?= base_url("$this->theme_folder/$this->theme/assets/css/codebase.min.css"); ?>">
<!-- Codebase Core JS -->
<link rel="stylesheet"
    href="<?= base_url("$this->theme_folder/$this->theme/assets/js/plugins/slick/slick.min.css"); ?>">
<link rel="stylesheet"
    href="<?= base_url("$this->theme_folder/$this->theme/assets/js/plugins/slick/slick-theme.min.css"); ?>">
<link rel="stylesheet" href="<?= base_url()?>assets/css/leaflet.css" />
<div id="page-loader" class="show"></div>