<?php  if(!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<footer id="page-footer" class="bg-dark">
    <div class="content py-20 font-size-xs clearfix">
        <div class="float-right "><span class="font-w600 text-white"> Thanks </span>
           <i class="fa fa-heart text-pulse"></i> <a target="_blank" href="https://github.com/OpenSID/OpenSID" class="font-w600 text-white"> OpenSID <?= AmbilVersi()?></a>
        </div>
        <div class="float-left">
            <a class="font-w600 text-white" href="http://dev.labkoding.id" target="_blank">Themes LABS - dev.labkoding.id / Nazrul.Dev ©</a>  <span class="js-year-copy text-white">2019</span>
        </div>
    </div>
</footer>